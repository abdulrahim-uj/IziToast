



Change Log
==========

0.0.1 (20/12/2022)
-------------------
- First Release

0.0.2 (20/12/2022)
-------------------
- Fixed mouse hover close issue

0.0.3 (21/12/2022)
-------------------
- Bug fixed

0.0.4 (21/12/2022)
-------------------
- Bug fixed

0.0.5 (21/12/2022)
-------------------
- Bug fixed
- Removed

0.0.6 (21/12/2022)
-------------------
- Bug fixed
- Removed

0.0.7 (21/12/2022)
-------------------
- Bug fixed
- Removed

0.0.8 (21/12/2022)
-------------------
- Bug fixed
- Removed

0.0.9 (21/12/2022)
-------------------
- Bug fixed
- Removed

0.1.9 (21/12/2022)
-------------------
- Bug fixed
- Removed

1.0.1 (21/12/2022)
-------------------
- Bug fixed
- Removed

1.0.2 (21/12/2022)
-------------------
- Bug fixed
- Removed

1.0.3 (21/12/2022)
-------------------
- Bug fixed
- Removed

1.0.4 (21/12/2022)
-------------------
- Bug fixed
- Removed

1.0.5 (21/12/2022)
-------------------
- Bug fixed
- Removed

1.0.6 (21/12/2022)
-------------------
- Bug fixed
- Removed

1.0.7 (21/12/2022)
-------------------
- Bug fixed
- Improved performance
- Size reduced
- Add more options
